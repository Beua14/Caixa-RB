// main.dart
// Caixa RB App - Flutter (single-file example)
// NOTE: This is a functional, but simplified, starter app. You'll want to split files
// and harden security for production. Use this as a working template to build and
// then upload to a build service like Codemagic.

import 'dart:io';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:path/path.dart' as p;
import 'package:intl/intl.dart';
import 'package:crypto/crypto.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path_provider/path_provider.dart';
import 'package:csv/csv.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:charts_flutter/flutter.dart' as charts;

// Pubspec dependencies (add to pubspec.yaml):
// sdk: ">=2.17.0 <3.0.0"
// dependencies:
//   flutter:
//     sdk: flutter
//   sqflite: ^2.2.8
//   path_provider: ^2.0.14
//   path: ^1.8.3
//   intl: ^0.18.1
//   crypto: ^3.0.2
//   csv: ^5.0.0
//   pdf: ^3.11.0
//   printing: ^5.10.0
//   charts_flutter: ^0.12.0

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final db = await AppDatabase.open();
  runApp(MyApp(db: db));
}

class MyApp extends StatelessWidget {
  final AppDatabase db;
  MyApp({required this.db});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Caixa RB',
      theme: ThemeData(
        scaffoldBackgroundColor: Color(0xFFFAFAFA), // off-white background
        primarySwatch: Colors.blue,
      ),
      home: StartupScreen(db: db),
    );
  }
}

// -------------------- DATABASE --------------------
class AppDatabase {
  final Database db;
  AppDatabase._(this.db);

  static Future<AppDatabase> open() async {
    final docs = await getApplicationDocumentsDirectory();
    final path = p.join(docs.path, 'daily_ledger.db');
    final db = await openDatabase(path, version: 1, onCreate: (db, v) async {
      await db.execute('''
        CREATE TABLE users(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          email TEXT UNIQUE,
          passwordHash TEXT
        )
      ''');
      await db.execute('''
        CREATE TABLE period_records(
          id TEXT PRIMARY KEY,
          date TEXT,
          period TEXT,
          sold REAL,
          outflow REAL,
          remaining REAL
        )
      ''');
    });
    return AppDatabase._(db);
  }

  Future<void> insertUser(String email, String hash) async {
    await db.insert('users', {'email': email, 'passwordHash': hash});
  }

  Future<Map<String, dynamic>?> getUser(String email) async {
    final rows = await db.query('users', where: 'email = ?', whereArgs: [email]);
    if (rows.isEmpty) return null;
    return rows.first;
  }

  Future<List<Map<String, dynamic>>> getAllRecords() async {
    return await db.query('period_records', orderBy: 'date DESC, period ASC');
  }

  Future<Map<String, dynamic>?> getRecordById(String id) async {
    final rows = await db.query('period_records', where: 'id = ?', whereArgs: [id]);
    return rows.isEmpty ? null : rows.first;
  }

  Future<void> upsertRecord(Map<String, dynamic> rec) async {
    await db.insert('period_records', rec, conflictAlgorithm: ConflictAlgorithm.replace);
  }
}

// -------------------- STARTUP / LOGIN --------------------
class StartupScreen extends StatefulWidget {
  final AppDatabase db;
  StartupScreen({required this.db});

  @override
  _StartupScreenState createState() => _StartupScreenState();
}

class _StartupScreenState extends State<StartupScreen> {
  final emailCtrl = TextEditingController();
  final passCtrl = TextEditingController();
  String message = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Caixa RB — Login')),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(children: [
          TextField(controller: emailCtrl, decoration: InputDecoration(labelText: 'E-mail')),
          TextField(controller: passCtrl, decoration: InputDecoration(labelText: 'Senha'), obscureText: true),
          SizedBox(height: 12),
          ElevatedButton(onPressed: _registerOrLogin, child: Text('Entrar / Registrar')),
          SizedBox(height: 8),
          Text(message, style: TextStyle(color: Colors.red)),
          SizedBox(height: 16),
          Text('O app é 100% offline — seu e-mail e senha são guardados localmente.'),
        ]),
      ),
    );
  }

  Future<void> _registerOrLogin() async {
    final email = emailCtrl.text.trim();
    final pass = passCtrl.text;
    if (email.isEmpty || pass.isEmpty) {
      setState(() => message = 'Preencha e-mail e senha');
      return;
    }
    final user = await widget.db.getUser(email);
    final hash = sha256.convert(utf8.encode(pass)).toString();
    if (user == null) {
      // register
      await widget.db.insertUser(email, hash);
      Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => HomeScreen(db: widget.db, userEmail: email)));
    } else {
      if (user['passwordHash'] == hash) {
        Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => HomeScreen(db: widget.db, userEmail: email)));
      } else {
        setState(() => message = 'Senha incorreta');
      }
    }
  }
}

// -------------------- MAIN APP --------------------
class HomeScreen extends StatefulWidget {
  final AppDatabase db;
  final String userEmail;
  HomeScreen({required this.db, required this.userEmail});

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  List<Map<String, dynamic>> records = [];

  final soldCtrl = TextEditingController();
  final outCtrl = TextEditingController();
  String feedback = '';

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    _loadAll();
  }

  Future<void> _loadAll() async {
    records = await widget.db.getAllRecords();
    setState(() {});
  }

  String todayDate() => DateFormat('yyyy-MM-dd').format(DateTime.now());

  String detectPeriod() {
    final h = DateTime.now().hour;
    return (h >= 7 && h <= 14) ? 'M' : 'T';
  }

  String formatKz(double value) {
    final rounded = value.round();
    final formatter = NumberFormat('#,##0', 'pt_BR');
    // replace comma with dot
    return '${formatter.format(rounded).replaceAll(',', '.')} Kz';
  }

  Future<void> saveNow() async {
    final sold = double.tryParse(soldCtrl.text.replaceAll('.', '').replaceAll(',', '.')) ?? 0.0;
    final outflow = double.tryParse(outCtrl.text.replaceAll('.', '').replaceAll(',', '.')) ?? 0.0;
    final date = todayDate();
    final period = detectPeriod();
    final id = '$date-$period';

    final existing = await widget.db.getRecordById(id);
    final prevRem = existing != null ? (existing['remaining'] as num).toDouble() : 0.0;
    final rem = prevRem + sold - outflow;
    await widget.db.upsertRecord({'id': id, 'date': date, 'period': period, 'sold': sold, 'outflow': outflow, 'remaining': rem});
    soldCtrl.clear();
    outCtrl.clear();
    await _loadAll();
    setState(() { feedback = 'Salvo para $date período $period'; });
  }

  // Export CSV
  Future<String> exportCsv() async {
    final rows = <List<dynamic>>[];
    rows.add(['Data','Turno','Entradas','Saídas','Saldo Restante']);
    for (var r in records.reversed) {
      final periodLabel = r['period']=='M' ? 'Manhã' : 'Tarde';
      rows.add([
        r['date'],
        periodLabel,
        r['sold'].toStringAsFixed(0),
        r['outflow'].toStringAsFixed(0),
        r['remaining'].toStringAsFixed(0),
      ]);
    }
    final csv = const ListToCsvConverter().convert(rows);
    final docs = await getApplicationDocumentsDirectory();
    final file = File(p.join(docs.path, 'daily_ledger_export_${DateTime.now().millisecondsSinceEpoch}.csv'));
    await file.writeAsString(csv);
    return file.path;
  }

  // Export PDF (simple, colored professional style)
  Future<String> exportPdf() async {
    final pdf = pw.Document();
    final titleStyle = pw.TextStyle(fontSize: 20, fontWeight: pw.FontWeight.bold);
    final small = pw.TextStyle(fontSize: 10);

    pdf.addPage(
      pw.MultiPage(
        pageFormat: pw.PageFormat.a4,
        build: (context) {
          return [
            pw.Header(level: 0, child: pw.Text('Caixa RB', style: titleStyle)),
            pw.Text('Período: Todos os dias registrados'),
            pw.SizedBox(height: 8),
            pw.Container(height: 2, color: PdfColor.fromInt(0xFF2196F3)),
            pw.SizedBox(height: 8),
            pw.Table.fromTextArray(
              context: context,
              data: <List<String>>[
                ['Data','Turno','Entradas','Saídas','Saldo Restante'],
                ...records.reversed.map((r) => [
                  r['date'],
                  r['period']=='M' ? 'Manhã' : 'Tarde',
                  formatKz((r['sold'] as num).toDouble()),
                  formatKz((r['outflow'] as num).toDouble()),
                  formatKz((r['remaining'] as num).toDouble()),
                ])
              ],
              headerStyle: pw.TextStyle(color: PdfColor.fromInt(0xFFFFFFFF)),
              headerDecoration: pw.BoxDecoration(color: PdfColor.fromInt(0xFF2196F3)),
              rowDecoration: pw.BoxDecoration(border: pw.Border(bottom: pw.BorderSide(width: .2))),
            ),
            pw.SizedBox(height: 12),
            pw.Container(
              padding: pw.EdgeInsets.all(8),
              color: PdfColor.fromInt(0xFF4CAF50),
              child: pw.Text('Resumo Total (todas as datas)', style: pw.TextStyle(color: PdfColor.fromInt(0xFFFFFFFF), fontSize: 12)),
            ),
            pw.SizedBox(height: 6),
            pw.Text(_summaryText()),
            pw.Spacer(),
            pw.Divider(),
            pw.Text('Relatório gerado automaticamente pelo Caixa RB App', style: small)
          ];
        }
      )
    );

    final bytes = await pdf.save();
    final docs = await getApplicationDocumentsDirectory();
    final path = p.join(docs.path, 'daily_ledger_${DateTime.now().millisecondsSinceEpoch}.pdf');
    final file = File(path);
    await file.writeAsBytes(bytes);
    return file.path;
  }

  String _summaryText(){
    final totalM = records.where((r)=>r['period']=='M').fold(0.0, (s, r) => s + (r['sold'] as num).toDouble());
    final totalT = records.where((r)=>r['period']=='T').fold(0.0, (s, r) => s + (r['sold'] as num).toDouble());
    final outM = records.where((r)=>r['period']=='M').fold(0.0, (s, r) => s + (r['outflow'] as num).toDouble());
    final outT = records.where((r)=>r['period']=='T').fold(0.0, (s, r) => s + (r['outflow'] as num).toDouble());
    final totalSold = totalM + totalT;
    final totalOut = outM + outT;
    final totalRem = records.isNotEmpty ? (records.first['remaining'] as num).toDouble() : 0.0;
    final percM = totalSold==0 ? 0 : ((totalM/totalSold)*100).round();
    final percT = totalSold==0 ? 0 : ((totalT/totalSold)*100).round();

    return 'Total Manhã: ${formatKz(totalM)} ($percM%)\\nTotal Tarde: ${formatKz(totalT)} ($percT%)\\nTotal Entradas: ${formatKz(totalSold)}\\nTotal Saídas: ${formatKz(totalOut)}\\nSaldo Restante: ${formatKz(totalRem)}';
  }

  // Build chart data for comparison
  List<charts.Series<ChartItem, String>> _buildChartData(){
    final grouped = <String, Map<String,double>>{}; // date -> {M: sold, T: sold}
    for(var r in records){
      final date = r['date'] as String;
      grouped.putIfAbsent(date, ()=>{'M':0.0,'T':0.0});
      grouped[date]![r['period'] as String] = grouped[date]![r['period'] as String]! + (r['sold'] as num).toDouble();
    }
    final morning = <ChartItem>[];
    final afternoon = <ChartItem>[];
    final sortedDates = grouped.keys.toList()..sort();
    for(var d in sortedDates){
      morning.add(ChartItem(d, grouped[d]!['M']!));
      afternoon.add(ChartItem(d, grouped[d]!['T']!));
    }
    return [
      charts.Series<ChartItem,String>(
        id: 'Manhã',
        domainFn: (c,_) => c.label,
        measureFn: (c,_) => c.value,
        data: morning,
        colorFn: (_,__) => charts.ColorUtil.fromDartColor(Colors.orange),
      ),
      charts.Series<ChartItem,String>(
        id: 'Tarde',
        domainFn: (c,_) => c.label,
        measureFn: (c,_) => c.value,
        data: afternoon,
        colorFn: (_,__) => charts.ColorUtil.fromDartColor(Colors.deepOrange),
      )
    ];
  }

  @override
  Widget build(BuildContext context) {
    final totalM = records.where((r)=>r['period']=='M').fold(0.0, (s, r) => s + (r['sold'] as num).toDouble());
    final totalT = records.where((r)=>r['period']=='T').fold(0.0, (s, r) => s + (r['sold'] as num).toDouble());
    final totalSold = totalM + totalT;
    final percM = totalSold==0 ? 0 : ((totalM/totalSold)*100).round();
    final percT = totalSold==0 ? 0 : ((totalT/totalSold)*100).round();

    return Scaffold(
      appBar: AppBar(
        title: Text('Caixa RB'),
        bottom: TabBar(controller: _tabController, tabs: [Tab(text:'Registros'), Tab(text:'Resumo'), Tab(text:'Comparação')]),
        actions: [
          PopupMenuButton<String>(onSelected: (v) async {
            if (v=='csv'){
              final path = await exportCsv();
              ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('CSV salvo: $path')));
            } else if (v=='pdf'){
              final path = await exportPdf();
              ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('PDF salvo: $path')));
            }
          }, itemBuilder: (_)=>[
            PopupMenuItem(value:'csv', child: Text('Exportar CSV')),
            PopupMenuItem(value:'pdf', child: Text('Exportar PDF')),
          ])
        ],
      ),
      body: TabBarView(controller: _tabController, children: [
        // Registros
        Padding(
          padding: EdgeInsets.all(16),
          child: Column(children: [
            Row(children: [
              Expanded(child: TextField(controller: soldCtrl, keyboardType: TextInputType.number, decoration: InputDecoration(labelText: 'Entradas (ex: 5.000)'))),
              SizedBox(width: 8),
              Expanded(child: TextField(controller: outCtrl, keyboardType: TextInputType.number, decoration: InputDecoration(labelText: 'Saídas (ex: 1.000)'))),
            ]),
            SizedBox(height: 12),
            ElevatedButton(onPressed: saveNow, child: Text('Salvar (turno detectado)')),
            SizedBox(height: 8),
            Text(feedback, style: TextStyle(color: Colors.green)),
            SizedBox(height: 12),
            Expanded(
              child: ListView.builder(itemCount: records.length, itemBuilder: (_, i){
                final r = records[i];
                final label = r['period']=='M' ? 'Manhã' : 'Tarde';
                return Card(
                  child: ListTile(
                    leading: Container(width:8, color: r['period']=='M' ? Colors.yellow[300] : Colors.orange[200]),
                    title: Text('${r['date']} | $label'),
                    subtitle: Text('Entradas: ${formatKz((r['sold'] as num).toDouble())} — Saídas: ${formatKz((r['outflow'] as num).toDouble())}'),
                    trailing: Text(formatKz((r['remaining'] as num).toDouble()), style: TextStyle(color: Colors.green[700])),
                  ),
                );
              }),
            )
          ]),
        ),

        // Resumo
        Padding(
          padding: EdgeInsets.all(16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('Resumo Geral', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            SizedBox(height: 12),
            Row(children: [
              Expanded(child: Container(padding: EdgeInsets.all(12), color: Colors.blue[50], child: Column(children: [Text('Total Entradas (Manhã)'), SizedBox(height:6), Text('${formatKz(totalM)} ($percM%)', style: TextStyle(color: Colors.blue))]))),
              SizedBox(width:8),
              Expanded(child: Container(padding: EdgeInsets.all(12), color: Colors.orange[50], child: Column(children: [Text('Total Entradas (Tarde)'), SizedBox(height:6), Text('${formatKz(totalT)} ($percT%)', style: TextStyle(color: Colors.deepOrange))]))),
            ]),
            SizedBox(height:12),
            Container(padding: EdgeInsets.all(12), color: Colors.green[50], child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text('Saldo Restante'), Text(formatKz(records.isNotEmpty ? (records.first['remaining'] as num).toDouble() : 0.0), style: TextStyle(color: Colors.green[800], fontWeight: FontWeight.bold))])),

            SizedBox(height:18),
            Text('Comparação por dia (tabela)', style: TextStyle(fontWeight: FontWeight.bold)),
            SizedBox(height:8),
            Expanded(child: ListView(children: records.reversed.map((r){
              final date = r['date'];
              final m = r['period']=='M' ? r['sold'] : 0.0;
              final t = r['period']=='T' ? r['sold'] : 0.0;
              return ListTile(title: Text('$date'), subtitle: Text('Entradas: ${formatKz(m)} | Saídas: ${formatKz(t)}'));
            }).toList()))
          ]),
        ),

        // Comparação (gráficos)
        Padding(
          padding: EdgeInsets.all(12),
          child: Column(children: [
            Text('Comparação de Turnos (todo o histórico)', style: TextStyle(fontWeight: FontWeight.bold)),
            SizedBox(height: 8),
            Expanded(child: charts.BarChart(_buildChartData(), animate: true, barGroupingType: charts.BarGroupingType.grouped)),
            SizedBox(height: 8),
            Container(padding: EdgeInsets.all(12), color: Colors.blue[50], child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text('Total Manhã'), Text('${formatKz(totalM)} ($percM%)', style: TextStyle(color: Colors.orange))])),
            SizedBox(height:8),
            Container(padding: EdgeInsets.all(12), color: Colors.orange[50], child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text('Total Tarde'), Text('${formatKz(totalT)} ($percT%)', style: TextStyle(color: Colors.deepOrange))])),
          ]),
        )
      ]),
    );
  }
}

class ChartItem { final String label; final double value; ChartItem(this.label,this.value); }

// -------------------- END --------------------
